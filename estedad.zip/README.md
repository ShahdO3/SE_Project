# Estedad
![estedad](https://user-images.githubusercontent.com/25493297/101259308-5b58a180-373d-11eb-8862-11addabbba38.png)<br>
Estedad is a Sans Serif Arabic-Latin typeface in <a href="https://aminabedi68.github.io/Estedad/">9 weights</a> and a <a href="https://aminabedi68.github.io/Estedad/VF.html">variable</a> version.
<br>Created with <a href="https://github.com/fontforge/fontforge">fontforge</a> and <a href="https://github.com/googlefonts/fontmake">fontmake</a>.
<br>Licensed under SIL open font License V1.1

## Fonts:
static fonts in 9 standard weights(Thin to black) and a variable font with 2 axes(Weight(`wght`):100-900 and Kashida(`kshd`):100-200) with 9 instances(placed on static weights coordinates).<br>
## Sources:
Font sources presented in fontforge's `SFD` files and a `designspace` file for variable font.
<br>
<br>
![estedad-2](https://user-images.githubusercontent.com/25493297/101951006-7cbd0000-3c0b-11eb-92ce-72ddbeec379f.png)
